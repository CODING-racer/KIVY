# SimpleGreetingApp
A Simple Kivy Greeting App
<br>
<br>
This is a very simple GUI App that receives a name text input from the user and returns a "Hello" greeting.
<br>
This App was created for learning purposes - so please feel free to use anything from it that may help you in your Python journey!
<br>
<br>
![text-Extract](https://user-images.githubusercontent.com/32107652/119795430-50313380-be8d-11eb-800f-43dc70d83035.jpg)
<br>
<br>
<b>SayHello_complete.py</b>
<br>
Is the complete Greeting App file.
<br>
<br>
<b>SayHello_starterCode.py</b>
<br>
Is the starter file to code from when following my step by step tutorial on Youtube.
<br>
Watch the Kivy GUI <b>tutorial on YouTube </b>:
<br>
https://youtu.be/YDp73WjNISc
<br>
<br>
<b>Author:</b> Mariya Sha
<br>
<b>LinkedIn:</b> www.linkedin.com/in/mariyasha888
<br>
<b>Youtube:</b> www.youtube.com/PythonSimplified
<br>
<b>Instagram:</b> www.instagram.com/mariyasha888
